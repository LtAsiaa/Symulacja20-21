#ifndef MODEL_PLATFORMH_H_
#define MODEL_PLATFORMH_H_

class PlatformH
{
public:
	PlatformH();
	~PlatformH();

private:
	const int idPlatform_; //id platform

};
#endif /*MODEL_PLATFORMH_H_*/